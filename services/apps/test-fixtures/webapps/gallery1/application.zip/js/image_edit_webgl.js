const ROT_MAT_IDX = Object.freeze({
  r0: 0,
  r90: 1,
  r180: 2,
  r270: 3
});
function WebGLCanvasHelper(canvas, lostCallback, restoreCallback, needRestore) {
  const self = this;
  this.canvas = canvas;
  this.needRestore = needRestore;
  this.lostHandler = function (event) {
    if (self.needRestore) {
      event.preventDefault();
    }
    if (lostCallback) {
      lostCallback();
    }
  };
  this.restoreHandler = function (event) {
    if (restoreCallback) {
      restoreCallback();
    }
  };
  canvas.addEventListener('webglcontextlost',
    this.lostHandler,
    false);
  canvas.addEventListener('webglcontextrestored',
    this.restoreHandler,
    false);
  const options = { depth: false, stencil: false, antialias: false };
  this.context = canvas.getContext('webgl',
    options) ||
    canvas.getContext('experimental-webgl',
      options);
  this.loseContextExt = this.context.getExtension('WEBGL_lose_context');
}

// Destroy the webgl canvas and context
WebGLCanvasHelper.prototype.destroy = function () {
  if (this.lostHandler) {
    this.canvas.removeEventListener('webglcontextlost',
      this.lostHandler,
      false);
  }
  if (this.restoreHandler) {
    this.canvas.removeEventListener('webglcontextrestored',
      this.restoreHandler,
      false);
  }
  this.context = null;
  this.canvas.width = this.canvas.height = 0;
  this.canvas = null;
  if (this.loseContextExt) {
    this.loseContextExt.loseContext();
  }
};

function ImageProcessor(canvas, lostCallback, restoreCallback) {
  if (lostCallback || restoreCallback) {
    this.webglHelper = new WebGLCanvasHelper(canvas,
      lostCallback,
      () => {
        this.initWebGL();
        if (restoreCallback) {
          restoreCallback();
        }
      }, true);
  } else {
    this.webglHelper = new WebGLCanvasHelper(canvas);
  }
  this.initWebGL();
}

// Init all webgl resource
ImageProcessor.prototype.initWebGL = function () {
  const gl = this.webglHelper.context;
  const vshader = this.vshader = gl.createShader(gl.VERTEX_SHADER);
  gl.shaderSource(vshader,
    ImageProcessor.vertexShader);
  gl.compileShader(vshader);
  if (!gl.getShaderParameter(vshader,
    gl.COMPILE_STATUS) &&
    !gl.isContextLost()) {
    const error = new Error(`Error compiling vertex shader:${
      gl.getShaderInfoLog(vshader)}`);
    gl.deleteShader(vshader);
    throw error;
  }
  const fshader = this.fshader = gl.createShader(gl.FRAGMENT_SHADER);
  gl.shaderSource(fshader,
    ImageProcessor.fragmentShader);
  gl.compileShader(fshader);
  if (!gl.getShaderParameter(fshader,
    gl.COMPILE_STATUS) &&
    !gl.isContextLost()) {
    const error = new Error(`Error compiling fragment shader:${
      gl.getShaderInfoLog(fshader)}`);
    gl.deleteShader(fshader);
    throw error;
  }
  const program = this.program = gl.createProgram();
  gl.attachShader(program,
    vshader);
  gl.attachShader(program,
    fshader);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program,
    gl.LINK_STATUS) &&
    !gl.isContextLost()) {
    const error = new Error(`Error linking GLSL program:${
      gl.getProgramInfoLog(program)}`);
    gl.deleteProgram(program);
    throw error;
  }
  gl.useProgram(program);
  this.sourceTexture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D,
    this.sourceTexture);
  gl.texParameteri(gl.TEXTURE_2D,
    gl.TEXTURE_WRAP_S,
    gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D,
    gl.TEXTURE_WRAP_T,
    gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D,
    gl.TEXTURE_MIN_FILTER,
    gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D,
    gl.TEXTURE_MAG_FILTER,
    gl.NEAREST);
  this.rectangleBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER,
    this.rectangleBuffer);
  gl.disable(gl.CULL_FACE);
  gl.bufferData(gl.ARRAY_BUFFER,
    new Float32Array([
      0,
      0,
      1,
      0,
      0,
      1,
      1,
      1
    ]), gl.STATIC_DRAW);
  this.rectangleVertexAddress = gl.getAttribLocation(program,
    'rect_vertex');
  this.srcRectangleAddress = gl.getUniformLocation(program,
    'src_rect');
  this.dstRectangleAddress = gl.getUniformLocation(program,
    'dst_rect');
  this.canvasSizeAddress = gl.getUniformLocation(program,
    'canvas_size');
  this.imageSizeAddress = gl.getUniformLocation(program,
    'image_size');
  this.destSizeAddress = gl.getUniformLocation(program,
    'dest_size');
  this.destOriginAddress = gl.getUniformLocation(program,
    'dest_origin');
  this.matrixAddress = gl.getUniformLocation(program,
    'matrix');
  this.matRotateAddress = gl.getUniformLocation(program,
    "mat_rotate");
  this.gammaAddress = gl.getUniformLocation(program,
    'gamma');
  this.rgbMinAddress = gl.getUniformLocation(program,
    'rgb_min');
  this.rgbMaxAddress = gl.getUniformLocation(program,
    'rgb_max');
  this.rgbOneOverMaxMinusMinAddress =
    gl.getUniformLocation(program,
      'rgb_one_over_max_minus_min');
};

// Destroy all the stuff we allocated
ImageProcessor.prototype.destroy = function () {
  const gl = this.webglHelper.context;
  gl.deleteShader(this.vshader);
  gl.deleteShader(this.fshader);
  gl.deleteProgram(this.program);
  gl.deleteTexture(this.sourceTexture);
  gl.deleteBuffer(this.rectangleBuffer);
  gl.viewport(0,
    0,
    0,
    0);
  this.webglHelper.destroy();
  this.webglHelper = null;
};

ImageProcessor.prototype.draw = function (image, needsUpload,
  sx, sy, sw, sh,
  dx, dy, dw, dh,
  options) {
  const gl = this.webglHelper.context;
  gl.viewport(0,
    0,
    gl.drawingBufferWidth,
    gl.drawingBufferHeight);
  gl.uniform2f(this.canvasSizeAddress,
    this.webglHelper.canvas.width,
    this.webglHelper.canvas.height);
  gl.uniform2f(this.imageSizeAddress,
    image.width,
    image.height);
  gl.uniform2f(this.destOriginAddress,
    dx,
    dy);
  gl.uniform2f(this.destSizeAddress,
    dw,
    dh);
  let gammaArray;
  const { gamma } = options.exposure;
  if (gamma) {
    gl.uniform4f(this.gammaAddress,
      gamma,
      gamma,
      gamma,
      gamma);
  } else {
    gl.uniform4f(this.gammaAddress,
      1,
      1,
      1,
      1);
  }

  // Set the color transformation
  gl.uniformMatrix4fv(this.matrixAddress,
    false,
    options.effect.matrix || ImageProcessor.IDENTITY_MATRIX);

  gl.uniformMatrix4fv(this.matRotateAddress,
    false,
    ImageProcessor.rotate_matrix[options.rotate.matIdx]);
  const minMaxValuesMatrix = options.enhance.rgbMinMaxValues ||
                           ImageProcessor.default_enhancement;
  gl.uniform3f(this.rgbMinAddress,
    minMaxValuesMatrix[0],
    minMaxValuesMatrix[1],
    minMaxValuesMatrix[2]);
  gl.uniform3f(this.rgbMaxAddress,
    minMaxValuesMatrix[3],
    minMaxValuesMatrix[4],
    minMaxValuesMatrix[5]);
  gl.uniform3f(this.rgbOneOverMaxMinusMinAddress,
    1 / (minMaxValuesMatrix[3] - minMaxValuesMatrix[0]),
    1 / (minMaxValuesMatrix[4] - minMaxValuesMatrix[1]),
    1 / (minMaxValuesMatrix[5] - minMaxValuesMatrix[2]));

  gl.bindBuffer(gl.ARRAY_BUFFER,
    this.rectangleBuffer);
  gl.enableVertexAttribArray(this.rectangleVertexAddress);
  gl.vertexAttribPointer(this.rectangleVertexAddress,
    2,
    gl.FLOAT,
    false,
    0,
    0);

  gl.uniform4f(this.srcRectangleAddress,
    sx,
    sy,
    sw,
    sh);
  gl.uniform4f(this.dstRectangleAddress,
    dx,
    dy,
    dw,
    dh);
  if (needsUpload) {
    gl.texImage2D(gl.TEXTURE_2D,
      0,
      gl.RGBA,
      gl.RGBA,
      gl.UNSIGNED_BYTE,
      image);
  }
  gl.drawArrays(gl.TRIANGLE_STRIP,
    0,
    4);
  return !this.isContextLost();
};

ImageProcessor.prototype.isContextLost = function () {
  return this.webglHelper.context.isContextLost();
};

ImageProcessor.vertexShader =
  'uniform vec4 src_rect;\n' + // Source rectangle (x, y, width, height)
  'uniform vec4 dst_rect;\n' + // Destination rectangle (x, y, width, height)
  'attribute vec2 rect_vertex;\n' + // Vertex in standard (0, 0, 1, 1) rectangle
  'uniform vec2 canvas_size;\n' + // Size of destination canvas in pixels
  'uniform vec2 image_size;\n' + // Size of source image in pixels
  'uniform mat4 mat_rotate;\n' +
  'varying vec2 src_position;\n' + // Pass image pos to the fragment shader
  'void main() {\n' +
  '  vec2 src_pixel = src_rect.xy + rect_vertex * src_rect.zw;\n' +
  '  vec2 dst_pixel = dst_rect.xy + rect_vertex * dst_rect.zw;\n' +
  '  gl_Position = vec4(((dst_pixel/canvas_size)*2.0-1.0)*vec2(1,-1),0,1) * mat_rotate;\n' +
  '  src_position = src_pixel / image_size;\n' +
  '}';

ImageProcessor.fragmentShader =
  'precision mediump float;\n' +
  'uniform sampler2D image;\n' +
  'uniform vec2 dest_size;\n' + // Size of the destination rectangle
  'uniform vec2 dest_origin;\n' + // Upper-left corner of destination rectangle
  'uniform vec4 gamma;\n' +
  'uniform mat4 matrix;\n' +
  'uniform vec3 rgb_min;\n' +
  'uniform vec3 rgb_max;\n' +
  'uniform vec3 rgb_one_over_max_minus_min;\n' +
  'varying vec2 src_position;\n' + // From the vertex shader
  'void main() {\n' +

  /*
   * Otherwise take the image color, apply color and gamma correction and
   * the color manipulation matrix.
   */
  '  vec4 original_color = texture2D(image, src_position);\n' +
  '  vec3 clamped_color = clamp(original_color.xyz, rgb_min, rgb_max);\n' +
  '  vec4 corrected_color = \n' +
  '    vec4((clamped_color.xyz - rgb_min) * rgb_one_over_max_minus_min, \n' +
  '         original_color.a);\n' +
  '  gl_FragColor = pow(corrected_color, gamma) * matrix;\n' +
  '}';

ImageProcessor.IDENTITY_MATRIX = [
  1,
  0,
  0,
  0,
  0,
  1,
  0,
  0,
  0,
  0,
  1,
  0,
  0,
  0,
  0,
  1
];

ImageProcessor.rotate_matrix = {};
ImageProcessor.rotate_matrix[ROT_MAT_IDX.r0] = ImageProcessor.IDENTITY_MATRIX;
ImageProcessor.rotate_matrix[ROT_MAT_IDX.r90] = [
  0,
  1,
  0,
  0,
  -1,
  0,
  0,
  0,
  0,
  0,
  1,
  0,
  0,
  0,
  0,
  1
];
ImageProcessor.rotate_matrix[ROT_MAT_IDX.r180] = [
  -1,
  0,
  0,
  0,
  0,
  -1,
  0,
  0,
  0,
  0,
  1,
  0,
  0,
  0,
  0,
  1
];
ImageProcessor.rotate_matrix[ROT_MAT_IDX.r270] = [
  0,
  -1,
  0,
  0,
  1,
  0,
  0,
  0,
  0,
  0,
  1,
  0,
  0,
  0,
  0,
  1
];

ImageProcessor.none_matrix = ImageProcessor.IDENTITY_MATRIX;

ImageProcessor.clear_matrix = [
  0.393,
  0.769,
  0.189,
  0,
  0.349,
  0.686,
  0.168,
  0,
  0.272,
  0.534,
  0.131,
  0,
  0,
  0,
  0,
  1
];

ImageProcessor.bw_matrix = [
  0.65,
  0.25,
  0.10,
  0,
  0.65,
  0.25,
  0.10,
  0,
  0.65,
  0.25,
  0.10,
  0,
  0,
  0,
  0,
  1
];

ImageProcessor.warm_matrix = [
  1,
  0.25,
  0.65,
  0,
  0.1,
  1,
  0.65,
  0,
  0.1,
  0.25,
  1,
  0.1,
  0,
  0,
  0,
  1
];

ImageProcessor.vivid_matrix = [
  1,
  0.2,
  0.2,
  0.03,
  0.2,
  0.7,
  0.2,
  0.05,
  0.1,
  0,
  0.8,
  0,
  0,
  0,
  0,
  1
];

ImageProcessor.default_enhancement = [
  0,
  0,
  0,
  1,
  1,
  1,
  0,
  0,
  0
];
