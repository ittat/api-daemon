'use strict';

(function (exports) {
  const Overlay = {
    scan: null,
    current: null,
    createdEmptypage: false,

    photosView: {
      src: '../style/images/empty-graphic.png',
      titletext: 'No Photos',
      description: 'Use camera to get started.',
      emptyBtn: {
        class: 'take-photo',
        text: 'TAKE PHOTO',
        clickCallback: null
      }
    },
    inAlbumView: {
      src: null,
      titletext: 'No Photos',
      description: null,
      emptyBtn: {
        class: 'add-photos',
        text: 'ADD PHOTOS',
        clickCallback: null
      }
    },
    favoriteView: {
      src: null,
      titletext: 'No Favorites',
      description: 'Photos you mark as favorite are shown here.',
      emptyBtn: null
    },
    pickMoreView: {
      src: null,
      titletext: 'No Photos',
      description: null,
      emptyBtn: null
    },

    createEmpty() {
      if (this.createdEmptypage) {
        return;
      }
      this.createdEmptypage = true;
      this.emptyContainer = document.querySelector('#overlay-container');
      this.emptyImg = document.createElement('div');
      this.emptyImg.classList.add('empty-img');
      this.emptyTitle = document.createElement('div');
      this.emptyTitle.classList.add('empty-title');
      this.emptyContext = document.createElement('div');
      this.emptyContext.classList.add('empty-context');
      this.emptyContainer.appendChild(this.emptyImg);
      this.emptyContainer.appendChild(this.emptyTitle);
      this.emptyContainer.appendChild(this.emptyContext);
    },

    showEmptyBtn(view) {
      this.emptyBtn = document.createElement('kai-pillbutton');
      this.emptyBtn.setAttribute('level',
        'secondary');
      this.emptyContainer.appendChild(this.emptyBtn);
      this.emptyBtn.setAttribute('class',
        this[view].emptyBtn.class);
      this.emptyBtn.setAttribute('text',
        this[view].emptyBtn.text);
      if (this[view].emptyBtn.clickCallback) {
        this.emptyBtn.addEventListener('click',
          () => {
            this[view].emptyBtn.clickCallback();
          });
      }
    },

    hideEmptyBtn() {
      if (!this.emptyBtn) {
        return;
      }
      this.emptyContainer.removeChild(this.emptyBtn);
      this.emptyBtn = null;
    },

    showEmptyPage(view) {
      document.body.classList.add(View.views.emptyView);
      if (view !== View.views.inAlbumView) {
        View.header.removeAttribute('menuoptions');
      }
      this.createEmpty();
      this.hideEmptyBtn();
      if (this[view].emptyBtn) {
        this.showEmptyBtn(view);
      }
      if (this[view].src) {
        this.emptyImg.style.backgroundImage = `url(${this[view].src})`;
      }
      this.emptyTitle.innerText = this[view].titletext;
      const description = this[view].description ? this[view].description : '';
      this.emptyContext.innerText = description;
      this.current = 'emptygallery';
    },

    hideEmptyPage() {
      document.body.classList.remove(View.views.emptyView);
      const options = View.headers[View.currentView].menuoptions;
      if (options) {
        View.header.setAttribute('menuoptions',
          JSON.stringify(options));
      } else {
        View.header.removeAttribute('menuoptions');
      }
      this.hideEmptyBtn();
      this.current = null;
    },

    showScanning() {
      if (!this.scan) {
        this.scan = document.querySelector('.scanning');
      }
      this.scan.classList.remove('hidden');
      this.current = 'scanning';
    },

    hideScanning() {
      this.scan.classList.add('hidden');
      this.current = null;
    }
  };
  exports.Overlay = Overlay;
}(window));
