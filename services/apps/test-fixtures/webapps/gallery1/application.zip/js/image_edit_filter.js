'use strict';
/* global ImageProcessor, ImageEditor, Preview, ImageEditView */
(function (exports) { // eslint-disable-line
  const ImageFilter = {
    filterNameTimeout: null,
    isShowFilterTools: false,

    enterFilterView() {
      this.showFilterTools();
      this.addEventListeners();
    },

    exitEditMode() {
      if (!this.tools) {
        return;
      }
      this.removeEventListeners();
      this.filterNameTimeout = null;
      this.isShowFilterTools = false;
      const filters = document.querySelectorAll('.image-filter-tool');
      [].forEach.call(filters, (el) => {
        if (el.id === 'image-filter-original') {
          el.classList.add('focus');
        } else {
          el.classList.remove('focus');
        }
        el.style.backgroundImage = '';
      });
    },

    showFilterTools() {
      if (this.isShowFilterTools) {
        return;
      }
      const el = document.querySelector('#image-filter-original');
      const matrix = ImageProcessor[`${el.dataset.effect}_matrix`];
      const { metadata } = Preview.previewFile.data;
      const blob = metadata.thumbnail;
      const ID = `${el.id}-canvas`;
      const editSettings = {
        crop: {
          x: 0, y: 0, w: metadata.width, h: metadata.height
        },
        exposure: {
          gamma: 1
        },
        rotate: {
          matIdx: 0
        },
        effect: {
          matrix
        },
        enhance: {
          rgbMinMaxValues: ImageProcessor.default_enhancement
        }
      };
      const filterOriginalImage = new Image();
      filterOriginalImage.src = URL.createObjectURL(blob);
      filterOriginalImage.onload = () => {
        let filterEditor = new ImageEditor(blob,
          el,
          ID,
          editSettings,
          () => {
            const filters = this.tools.querySelectorAll('.image-filter-tool');
            [].forEach.call(filters, (filter) => {
              const matrixID = filter.dataset.effect;
              if (matrixID === 'none') {
                this.setFilterToolsBackground(filterEditor, filter);
              } else {
                editSettings.effect.matrix =
                  ImageProcessor[`${matrixID}_matrix`];
                filterEditor.edit(() => {
                  this.setFilterToolsBackground(filterEditor, filter);
                  if (matrixID === 'bw') {
                    filterEditor.destroy();
                    filterEditor = null;
                    this.isShowFilterTools = true;
                  }
                });
              }
            });
          },
          false);
      };
    },

    setFilterToolsBackground(filterEditor, filter) {
      filterEditor.previewCanvas.toBlob((blob) => {
        const filterUrl = URL.createObjectURL(blob);
        filter.style.backgroundImage = `url(${filterUrl})`;
      }, 'image/jpeg');
    },

    showFilterName(filter) {
      const filterName = document.querySelector('#image-filter-tool-name');
      filterName.setAttribute('data-l10n-id', filter.id);
      filterName.classList.add('show');
      clearTimeout(this.filterNameTimeout);
      this.filterNameTimeout = setTimeout(() => {
        filterName.classList.remove('show');
      }, 1000);
    },

    addEventListeners() {
      if (this.tools) {
        return;
      }
      this.tools = document.querySelector('#image-filter-tools');
      this.filtersClickHandel = this.addFilter.bind(this);
      this.tools.addEventListener('click',
        this.filtersClickHandel);
    },

    removeEventListeners() {
      this.tools.removeEventListener('click',
        this.filtersClickHandel);
      this.tools = null;
      this.filtersClickHandel = null;
    },

    addFilter(e) {
      const { target } = e;
      if (!target.dataset.effect || target.classList.contains('focus')) {
        return;
      }
      const filters = this.tools.querySelectorAll('.image-filter-tool');
      [].forEach.call(filters, (el) => {
        el.classList.remove('focus');
      });
      target.classList.add('focus');
      ImageEditView.editSettings.effect.matrix =
        ImageProcessor[`${target.dataset.effect}_matrix`];
      ImageEditView.imageEditor.edit();
      this.showFilterName(target);
      ImageEditView.changeSaveBtnState(ImageEditView.imageEditor.isEdited());
    }
  };
  exports.ImageFilter = ImageFilter;
}(window));
