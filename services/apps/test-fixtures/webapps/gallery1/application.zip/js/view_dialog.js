'use strict';

(function (exports) {
  const Dialog = {
    show: false,
    createAlbum: {
      title: 'New Album',
      message: null,
      primarybtntext: 'CREATE',
      secondarybtntext: 'CANCEL'
    },
    addToAlbum: {
      title: 'Add To',
      message: null,
      primarybtntext: null,
      secondarybtntext: null
    },
    reachMaxAlbums: {
      title: 'Max Amount Reached',
      message: 'To create a new album, delete one of the current albums.',
      secondarybtntext: 'OK'
    },
    renameAlbum: {
      title: 'Rename Album',
      message: null,
      primarybtntext: 'RENAME',
      secondarybtntext: 'CANCEL'
    },
    delete: {
      title: 'Delete',
      message: 'Delete 0 photos?',
      primarybtntext: 'DELETE',
      secondarybtntext: 'CANCEL'
    },
    remove: {
      title: 'Remove',
      message: 'Remove 0 photos from album?',
      primarybtntext: 'REMOVE',
      secondarybtntext: 'CANCEL'
    },
    discard: {
      title: 'Discard',
      message: 'Discard changes?',
      primarybtntext: 'DISCARD',
      secondarybtntext: 'CANCEL'
    },
    phoneStorageFull: {
      title: 'Phone Storage Full',
      message: 'Delete media files or application data to free up space.' +
        'You can also insert an SD card to expand media storage.',
      primarybtntext: 'SETTINGS',
      secondarybtntext: 'CANCEL'
    },
    sdcardFull: {
      title: 'SD Card Full',
      message: 'Delete files in SD card to free up space.',
      primarybtntext: 'SETTINGS',
      secondarybtntext: 'CANCEL'
    },
    ratio: {
      title: 'Ratio',
      message: null,
      primarybtntext: null,
      secondarybtntext: null
    },
    dialog: null,
    lazyFiles: false,
    customView: null,
    contents: null,
    secondaryBtnCallback: null,

    createDialog() {
      this.dialog = document.createElement('kai-dialog');
      document.body.appendChild(this.dialog);
      this.dialog.open = false;
      document.addEventListener('dialogSecondaryBtnClick',
        (e) => {
          this.hideDialog();
        });
      document.addEventListener('dialogPrimaryBtnClick',
        (e) => {
          if (this.secondaryBtnCallback) {
            this.secondaryBtnCallback();
          }
        });
      this.initDialog();
    },

    showDialog(contents, customView, secondaryBtnCallback) {
      this.secondaryBtnCallback =
        secondaryBtnCallback ? secondaryBtnCallback : null;
      this.contents = contents;
      this.customView = customView ? customView : null;
      if (!this.dialog) {
        this.createDialog();
      } else {
        this.initDialog();
      }
    },

    initDialog() {
      this.dialog.className = '';
      this.dialog.title = this.contents.title;
      this.dialog.message = this.contents.message;
      this.dialog.primarybtntext = this.contents.primarybtntext;
      this.dialog.secondarybtntext = this.contents.secondarybtntext;
      this.dialog.primarybtndisabled = false;
      this.dialog.secondarybtndisabled = false;
      if (this.customView) {
        this.dialog.appendChild(this.customView);
      }
      this.dialog.open = true;
    },

    hideDialog() {
      if (this.customView) {
        this.dialog.removeChild(this.customView);
      }
      this.secondaryBtnCallback = null;
      this.customView = null;
      this.dialog.open = false;
    }
  };
  exports.Dialog = Dialog;
}(window));
