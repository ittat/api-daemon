'use strict';
(function (exports) {
  const Startup = {
    appLoaded: false,
    picking: window.location.hash === '#pick',
    lowMemory: false,
    CONFIG_MAX_IMAGE_PIXEL_SIZE: 5 * 1024 * 1024,
    CONFIG_MAX_SNAPSHOT_PIXEL_SIZE: 5 * 1024 * 1024,
    LOW_MAX_IMAGE_PIXEL_SIZE_NO_JPEG: 1431136,
    CONFIG_MAX_PICK_PIXEL_SIZE: 0,
    CONFIG_MAX_EDIT_PIXEL_SIZE: 0,
    CONFIG_REQUIRED_EXIF_PREVIEW_WIDTH: 0,
    CONFIG_REQUIRED_EXIF_PREVIEW_HEIGHT: 0,
    thumbnailColumn: 3,

    start() {
      // InitActivity();
      window.dispatchEvent(new CustomEvent('moz-chrome-dom-loaded'));
      // Window.onresize = resizeHandler;
      window.performance.mark('navigationInteractive');
      window.dispatchEvent(new CustomEvent('moz-chrome-interactive'));
      this.getColumnCount();
      View.init();
      PhotoDB.initPhotodb();
    },

    getColumnCount() {
      const matchMedia = window.matchMedia('(orientation: landscape)');
      if (matchMedia.matches) {
        this.thumbnailColumn = 4;
      } else {
        this.thumbnailColumn = 3;
      }
    },

    pendingInit() {
      window.removeEventListener('load',
        Startup.pendingInit);
      window.setTimeout(() => {
        const lazyFiles = [
          'shared/style/toaster.css',
          'shared/js/toaster.js',
          'js/pickeditor.js'
        ];
        LazyLoader.load(lazyFiles);
      }, 500);
    }
  };
  exports.Startup = Startup;
  window.addEventListener('largetextenabledchanged',
    () => {
      document.body.classList.toggle('large-text',
        navigator.largeTextEnabled);
    });
  window.addEventListener('load',
    Startup.pendingInit);
  ScreenLayout.watch('portrait',
    '(orientation: portrait)');
  navigator.getFeature('hardware.memory').then((memOnDevice) => {
    if (memOnDevice === 256) {
      Startup.lowMemory = true;
      Startup.CONFIG_MAX_IMAGE_PIXEL_SIZE = 2 * 1024 * 1024;
      Startup.CONFIG_MAX_SNAPSHOT_PIXEL_SIZE = 1600 * 1200;
      Startup.CONFIG_MAX_PICK_PIXEL_SIZE = 800 * 600;
      Startup.CONFIG_MAX_EDIT_PIXEL_SIZE = 800 * 600;
    }
  });
  navigator.mozL10n.once(() => {
    Startup.start();
  });
}(window));
