'use strict';
(function (exports) {
  const Options = {
    items: null,

    initItems() {
      this.items = {
        group: {
          label: 'Group by date',
          value: 'group',
          callback: Photos.groupOrUngroupThumbnails.bind(Photos,
            true)
        },
        ungroup: {
          label: 'Ungroup',
          value: 'ungroup',
          callback: Photos.groupOrUngroupThumbnails.bind(Photos,
            false)
        },
        addAlbum: {
          label: 'Add to album',
          value: 'addAlbum',
          callback: null
        },
        removeAlbum: {
          label: 'Remove from album',
          value: 'removeAlbum',
          callback: null
        },
        fileInfo: {
          label: 'File info',
          value: 'fileInfo',
          callback: null
        },
        addPhotos: {
          label: 'Add Photos',
          value: 'addPhotos',
          callback: null
        },
        renameAlbum: {
          label: 'Rename album',
          value: 'renameAlbum',
          callback: null
        },
        deleteAlbum: {
          label: 'Delete album',
          value: 'deleteAlbum',
          callback: null
        }
      };
    },

    initOptionmenuSelect() {
      this.initItems();
      document.addEventListener('optionmenuSelect',
        (e) => {
          const { selected } = e.detail;
          if (this.items[selected].callback) {
            this.items[selected].callback();
          }
        });
    }
  };
  Options.initOptionmenuSelect();
  exports.Options = Options;
}(window));
