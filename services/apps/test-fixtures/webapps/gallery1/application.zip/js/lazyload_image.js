function LazyLoadImage(container) {
  this.container = container;
  this.poll = null;
  this.delay = 20;
}

LazyLoadImage.prototype.debounceOrThrottle = function () {
  clearTimeout(this.poll);
  this.poll = setTimeout(() => {
    this.render();
    this.poll = null;
  }, this.delay);
};

LazyLoadImage.prototype.inView = function (element, view) {
  const box = element.getBoundingClientRect();
  return box.right >= view.l && box.bottom >= view.t &&
      box.left <= view.r && box.top <= view.b;
};

LazyLoadImage.prototype.init = function (container) {
  this.container = container;
  this.render();
  this.container.addEventListener('scroll',
    this.debounceOrThrottle.bind(this));
  this.container.addEventListener('load',
    this.debounceOrThrottle.bind(this));
};

LazyLoadImage.prototype.render = function () {
  const nodes = this.container.querySelectorAll('.thumbnail');
  const { length } = nodes;
  let elem;
  const view = {
    l: 0,
    t: -document.documentElement.clientHeight,
    b: document.documentElement.clientHeight * 2,
    r: document.documentElement.clientWidth
  };
  for (let i = 0; i < length; i++) {
    elem = nodes[i];
    if (this.inView(elem,
      view)) {
      if (elem.getAttribute('load-image') === 'false') {
        elem.setAttribute('load-image',
          'true');
        elem.style.backgroundImage =
          `url(${elem.getAttribute('data-src')})`;
      }
    } else {
      elem.setAttribute('load-image',
        'false');
      elem.style.backgroundImage = '';
    }
  }
  if (!length) {
    this.detach();
  }
};

LazyLoadImage.prototype.detach = function () {
  this.container.removeEventListener('scroll',
    this.debounceOrThrottle.bind(this));
  clearTimeout(this.poll);
};
