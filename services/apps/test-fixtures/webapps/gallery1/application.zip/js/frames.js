'use strict';
(function (exports) {
  const Frames = {
    frames: null,
    frameOffset: 0,
    FRAME_BORDER_WIDTH: 3,
    currentFileKey: null,
    transitioning: false,
    taptimer: null,
    TRANSITION_FRACTION: 0.25,
    TRANSITION_SPEED: 0.75,
    showFocusView: false,
    MAX_ZOOM_IN_RESOLUTION: 1024 * 1024,
    DEFAULT_DB_TAP_ZOOM_IN_SCALE: 2,

    initFrames() {
      this.initGestureEvent();
      this.maxImageSize = Startup.CONFIG_MAX_IMAGE_PIXEL_SIZE;
      this.framePre = document.querySelector('#frame1');
      this.frameCur = document.querySelector('#frame2');
      this.frameNext = document.querySelector('#frame3');
      this.previousFrame =
        new MediaFrame(this.framePre,
          false,
          this.maxImageSize);
      this.currentFrame =
        new MediaFrame(this.frameCur,
          false,
          this.maxImageSize);
      this.nextFrame =
        new MediaFrame(this.frameNext,
          false,
          this.maxImageSize);
      if (Startup.CONFIG_REQUIRED_EXIF_PREVIEW_WIDTH) {
        this.previousFrame.setMinimumPreviewSize(
          Startup.CONFIG_REQUIRED_EXIF_PREVIEW_WIDTH,
          Startup.CONFIG_REQUIRED_EXIF_PREVIEW_HEIGHT);
        this.currentFrame.setMinimumPreviewSize(
          Startup.CONFIG_REQUIRED_EXIF_PREVIEW_WIDTH,
          Startup.CONFIG_REQUIRED_EXIF_PREVIEW_HEIGHT);
        this.nextFrame.setMinimumPreviewSize(
          Startup.CONFIG_REQUIRED_EXIF_PREVIEW_WIDTH,
          Startup.CONFIG_REQUIRED_EXIF_PREVIEW_HEIGHT);
      }
      window.addEventListener('moveframe',
        () => {
          if (PhotoDB.photodb.parsingBigFiles) {
            return;
          }
          const deltax = 6;
          switch (e.detail.keyId) {
            case 0:
              this.currentFrame.pan(deltax,
                0);
              break;
            case 1:
              this.currentFrame.pan(-deltax,
                0);
              break;
            case 2:
              this.currentFrame.pan(0,
                deltax);
              break;
            case 3:
              this.currentFrame.pan(0,
                -deltax);
              break;
          }
        });
      this.previousFrame.container.addEventListener('transitionend',
        (event) => {
          event.target.style.transition = null;
        });
      this.currentFrame.container.addEventListener('transitionend',
        (event) => {
          event.target.style.transition = null;
        });
      this.nextFrame.container.addEventListener('transitionend',
        (event) => {
          event.target.style.transition = null;
        });
    },

    initGestureEvent() {
      this.frames = document.querySelector('#frames');
      new GestureDetector(this.frames).startDetecting();
      this.frames.addEventListener('tap',
        this.tapHandler.bind(this));
      this.frames.addEventListener('dbltap',
        this.dblTapHandler.bind(this));
      this.frames.addEventListener('pan',
        this.panHandler.bind(this));
      this.frames.addEventListener('swipe',
        this.swipeHandler.bind(this));
      this.frames.addEventListener('transform',
        this.transformHandler.bind(this));
    },

    tapHandler() {
      if (this.taptimer) {
        return;
      }
      this.taptimer = setTimeout(() => {
        this.taptimer = null;
        if (this.showFocusView) {
          this.exitFocusView();
        } else {
          this.enterFocusView();
        }
      }, GestureDetector.DOUBLE_TAP_TIME);
    },

    enterFocusView() {
      this.showFocusView = true;
      this.frames.parentNode.classList.add('toolbar-hidden');
    },

    exitFocusView() {
      this.showFocusView = false;
      this.frames.parentNode.classList.remove('toolbar-hidden');
    },

    dblTapHandler(e) {
      clearTimeout(this.taptimer);
      const frame = this.currentFrame;
      this.taptimer = null;
      if (Preview.previewFile.data.metadata.largeSize ||
        PhotoDB.photodb.parsingBigFiles) {
        return;
      }
      if (!this.showFocusView) {
        this.enterFocusView();
      }
      let scale;
      if (frame.fit.scale > frame.fit.baseScale) {
        scale = frame.fit.baseScale / frame.fit.scale;
      } else {
        scale = this.DEFAULT_DB_TAP_ZOOM_IN_SCALE;
      }
      if (frame.displayingPreview) {
        const that = this;
        const fullImage = new Image();
        fullImage.src = frame.fullImageURL;
        fullImage.addEventListener('load',
          function preLoadImage() {
            fullImage.removeEventListener('load',
              preLoadImage);
            frame._switchToFullSizeImage();
            that.zoomImage(scale,
              e.detail.clientX,
              e.detail.clientY,
              200);
          });
      } else {
        this.zoomImage(scale,
          e.detail.clientX,
          e.detail.clientY,
          200);
      }
    },

    panHandler(e) {
      if (this.transitioning) {
        return;
      }
      let { dx } = e.detail.relative;
      const { dy } = e.detail.relative;
      const oldFrameOffset = this.frameOffset;
      const currentFileIndex = this.getCurrentIndex(this.currentFrame.filename);
      const allThumbnailCount = this.getThumbnailCount();
      if (this.frameOffset > 0 && dx > 0 || this.frameOffset < 0 && dx < 0 ||
          this.frameOffset !== 0 && this.frameOffset > -dx) {
        this.frameOffset += dx;
      } else {
        if (this.frameOffset !== 0) {
          dx += this.frameOffset;
          this.frameOffset = 0;
        }
        this.frameOffset += this.currentFrame.pan(dx,
          dy);
      }
      if (document.documentElement.dir === 'ltr') {
        if (currentFileIndex === 0 && this.frameOffset > 0 ||
          currentFileIndex === allThumbnailCount - 1 &&
          this.frameOffset < 0) {
          this.frameOffset = 0;
        }
      } else if (currentFileIndex === 0 && this.frameOffset < 0 ||
          currentFileIndex === allThumbnailCount - 1 &&
          this.frameOffset > 0) {
        this.frameOffset = 0;
      }
      if (this.frameOffset !== oldFrameOffset) {
        this.setFramesPosition();
      }
    },

    swipeHandler(e) {
      const currentFileIndex = this.getCurrentIndex(this.currentFrame.filename);
      const allThumbnailCount = this.getThumbnailCount();
      if (this.transitioning) {
        return;
      }
      if (this.frameOffset === 0) {
        return;
      }
      let direction = this.frameOffset < 0 ? 1 : -1;
      if (document.documentElement.dir === 'rtl') {
        direction *= -1;
      }
      const farenough = Math.abs(this.frameOffset) >
        window.innerWidth * this.TRANSITION_FRACTION;
      const velocity = e.detail.vx;
      const fastenough = Math.abs(velocity) > this.TRANSITION_SPEED;
      const samedirection = velocity === 0 || this.frameOffset / velocity >= 0;
      const fileexists =
        direction === 1 && currentFileIndex + 1 < allThumbnailCount ||
        direction === -1 && currentFileIndex > 0;
      let time;
      if (direction !== 0 && (farenough || fastenough) &&
          samedirection && fileexists) {
        const speed = Math.max(Math.abs(velocity),
          this.TRANSITION_SPEED);
        time = (window.innerWidth - Math.abs(this.frameOffset)) / speed;
        if (direction === 1) {
          this.showNextFile(time);
        } else {
          this.showPreviousFile(time);
        }
      } else if (this.frameOffset !== 0) {
        time = Math.abs(this.frameOffset) / this.TRANSITION_SPEED;
        this.currentFrame.container.style.transition =
          `transform ${time}ms ease`;
        this.nextFrame.container.style.transition =
          `transform ${time}ms ease`;
        this.previousFrame.container.style.transition =
          `transform ${time}ms ease`;
        this.resetFramesPosition();
        this.transitioning = true;
        setTimeout(() => {
          this.transitioning = false;
        }, time);
      }
    },

    transformHandler(e) {
      if (this.transitioning ||
        PhotoDB.photodb.parsingBigFiles ||
        Preview.previewFile.data.metadata.largeSize) {
        return;
      }
      if (!this.showFocusView) {
        this.enterFocusView();
      }
      const frame = this.currentFrame;
      if (frame.displayingPreview) {
        const that = this;
        const fullImage = new Image();
        fullImage.src = frame.fullImageURL;
        fullImage.addEventListener('load',
          function preLoadImage() {
            fullImage.removeEventListener('load',
              preLoadImage);
            frame._switchToFullSizeImage();
            that.zoomImage(e.detail.relative.scale,
              e.detail.midpoint.clientX,
              e.detail.midpoint.clientY);
          });
      } else {
        this.zoomImage(e.detail.relative.scale,
          e.detail.midpoint.clientX,
          e.detail.midpoint.clientY);
      }
    },

    getScaleResolution(scale, frame) {
      const fitWidth = Math.floor(frame.itemWidth * scale);
      const fitHeight = Math.floor(frame.itemHeight * scale);
      return fitWidth * fitHeight;
    },

    getMaxZoomInResolution(frame) {
      const nativeResolution = frame.itemWidth * frame.itemHeight;
      let maxZoomInResolution = this.MAX_ZOOM_IN_RESOLUTION;
      if (nativeResolution > maxZoomInResolution) {
        maxZoomInResolution = nativeResolution;
      }
      return maxZoomInResolution;
    },

    getMaxZoomInScale(frame) {
      const SCALE_DELTA = 0.1;
      let scale = frame.fit.baseScale;
      let scaleResolution = this.getScaleResolution(scale,
        frame);
      const maxZoomInResolution = this.getMaxZoomInResolution(frame);
      while (scaleResolution <= maxZoomInResolution) {
        scale += SCALE_DELTA;
        scaleResolution = this.getScaleResolution(scale,
          frame);
      }
      scale -= SCALE_DELTA;
      return scale;
    },

    zoomImage(scale, fixedX, fixedY, time) {
      const frame = this.currentFrame;
      if (!frame.displayingImage) {
        return;
      }
      if (frame.fit.scale * scale < frame.fit.baseScale) {
        scale = frame.fit.baseScale / frame.fit.scale;
      }
      if (!frame.maxZoomInScale) {
        frame.maxZoomInScale = this.getMaxZoomInScale(frame);
      }
      if (frame.fit.scale * scale > frame.maxZoomInScale) {
        scale = frame.maxZoomInScale / frame.fit.scale;
      }
      frame.fit.scale = frame.fit.scale * scale;
      frame.fit.width = Math.floor(frame.itemWidth * frame.fit.scale);
      frame.fit.height = Math.floor(frame.itemHeight * frame.fit.scale);
      let photoX = fixedX - frame.fit.left;
      let photoY = fixedY - frame.fit.top;
      photoX = Math.floor(photoX * scale);
      photoY = Math.floor(photoY * scale);
      frame.fit.left = fixedX - photoX;
      frame.fit.top = fixedY - photoY;
      if (frame.fit.width <= frame.viewportWidth) {
        frame.fit.left = (frame.viewportWidth - frame.fit.width) / 2;
      } else {
        if (frame.fit.left > 0) {
          frame.fit.left = 0;
        }
        if (Math.abs(frame.fit.left) + frame.fit.width < frame.viewportWidth) {
          frame.fit.left = frame.viewportWidth - frame.fit.width;
        }
      }
      if (frame.fit.height <= frame.viewportHeight) {
        frame.fit.top = (frame.viewportHeight - frame.fit.height) / 2;
      } else {
        if (frame.fit.top > 0) {
          frame.fit.top = 0;
        }
        if (Math.abs(frame.fit.top) + frame.fit.height < frame.viewportHeight) {
          frame.fit.top = frame.viewportHeight - frame.fit.height;
        }
      }
      if (time) {
        const transition = `transform ${time}ms ease`;
        frame.image.style.transition = transition;
        frame.image.addEventListener('transitionend',
          function done() {
            frame.image.removeEventListener('transitionend',
              done);
            frame.image.style.transition = '';
          });
      }
      frame.setPosition();
    },

    updateFrames(item) {
      this.setupFrameContent(item,
        this.currentFrame);
      const nextItem = this.getNextItem();
      this.setupFrameContent(nextItem,
        this.nextFrame);
      const previousItem = this.getPreviousItem();
      this.setupFrameContent(previousItem,
        this.previousFrame);
      this.resetFramesPosition();
    },

    clearFrames() {
      this.clearFrame(this.previousFrame);
      this.clearFrame(this.currentFrame);
      this.clearFrame(this.nextFrame);
    },

    clearFrame(frame) {
      frame.clear();
      delete frame.filename;
      delete frame.metadata;
      delete frame.maxZoomInScale;
    },

    resizeFrames() {
      this.nextFrame.reset();
      this.previousFrame.reset();
      this.currentFrame.reset();
    },

    getListObject() {
      let listObj = null;
      switch (View.lastView) {
        case View.views.photosView:
          listObj = Photos;
          break;
        case View.views.inAlbumView:
          listObj = InAlbum;
          break;
        case View.views.favoriteView:
          listObj = Favorite;
          break;
      }
      return listObj;
    },

    getAllThumbnails() {
      const listObj = this.getListObject();
      return listObj.thumbnailList.getAllThumbnails();
    },

    getThumbnailCount() {
      const listObj = this.getListObject();
      return listObj.thumbnailList.getCount();
    },

    getCurrentIndex(name) {
      const listObj = this.getListObject();
      return listObj.thumbnailList.getThumbnailIndex(name);
    },

    getCurrentItem(name) {
      const listObj = this.getListObject();
      return listObj.thumbnailList.getThumbnail(name);
    },

    getNextItem() {
      const name = this.currentFrame.filename;
      const currentIndex = this.getCurrentIndex(name);
      const allThumbnails = this.getAllThumbnails();
      const nextItem = allThumbnails[currentIndex + 1];
      if (nextItem) {
        return nextItem;
      }
      return null;

    },

    getPreviousItem() {
      const name = this.currentFrame.filename;
      const currentIndex = this.getCurrentIndex(name);
      const allThumbnails = this.getAllThumbnails();
      const previousItem = allThumbnails[currentIndex - 1];
      if (previousItem) {
        return previousItem;
      }
      return null;

    },

    showNextFile(time) {
      let nextItem = this.getNextItem(this.currentFrame.filename);
      if (!nextItem) {
        return;
      }
      this.transitioning = true;
      const transition = `transform ${time}ms ease`;
      this.currentFrame.container.style.transition = transition;
      this.nextFrame.container.style.transition = transition;
      const tmp = this.previousFrame;
      this.previousFrame = this.currentFrame;
      this.currentFrame = this.nextFrame;
      this.nextFrame = tmp;
      const currentItem = this.getCurrentItem(this.currentFrame.filename);
      Preview.updatePreview(currentItem);
      nextItem = this.getNextItem(this.currentFrame.filename);
      this.resetFramesPosition();
      this.setupFrameContent(nextItem,
        this.nextFrame);
      const self = this;
      this.currentFrame.container.addEventListener(
        'transitionend',
        function done(e) {
          this.removeEventListener('transitionend',
            done);
          self.transitioning = false;
          self.previousFrame.reset();
        });
    },

    showPreviousFile(time) {
      let previousItem = this.getPreviousItem(this.currentFrame.filename);
      if (!previousItem) {
        return;
      }
      this.transitioning = true;
      const transition = `transform ${time}ms ease`;
      this.previousFrame.container.style.transition = transition;
      this.currentFrame.container.style.transition = transition;
      const tmp = this.nextFrame;
      this.nextFrame = this.currentFrame;
      this.currentFrame = this.previousFrame;
      this.previousFrame = tmp;
      const currentItem = this.getCurrentItem(this.currentFrame.filename);
      Preview.updatePreview(currentItem);
      previousItem = this.getPreviousItem(this.currentFrame.filename);
      this.resetFramesPosition();
      this.setupFrameContent(previousItem,
        this.previousFrame);
      const self = this;
      this.currentFrame.container.addEventListener(
        'transitionend',
        function done(e) {
          this.removeEventListener('transitionend',
            done);
          self.transitioning = false;
          self.nextFrame.reset();
        });
    },

    setupFrameContent(item, frame) {
      if (!item) {
        this.clearFrame(frame);
        return;
      }
      const file = item.data;
      frame.filename = file.name;
      frame.metadata = file.metadata;
      if (frame.invalidNode) {
        frame.container.removeChild(frame.invalidNode);
        frame.invalidNode = null;
      }
      PhotoDB.photodb.getFile(file.name,
        (imagefile) => {
          if (file.metadata.largeSize) {
            frame.clear();
            const invalidNode = this.creatInvalidImagePreview();
            frame.invalidNode = invalidNode;
            frame.container.appendChild(invalidNode);
          } else {
            frame.displayImage(
              imagefile,
              file.metadata.width,
              file.metadata.height,
              file.metadata.preview,
              file.metadata.rotation,
              file.metadata.mirrored,
              file.metadata.largeSize);
          }
        });
    },

    creatInvalidImagePreview() {
      const invalidNode = document.createElement('div');
      invalidNode.setAttribute('id',
        'invalid');
      const invalidIcon = document.createElement('i');
      invalidIcon.setAttribute('data-icon',
        'exclamation');
      invalidIcon.classList.add('invalid-icon');
      const invalidTitle = document.createElement('div');
      invalidTitle.setAttribute('data-l10n-id',
        'invalid-title');
      invalidTitle.classList.add('invalid-title');
      const invalidContext = document.createElement('div');
      invalidContext.setAttribute('data-l10n-id',
        'invalid-context');
      invalidContext.classList.add('invalid-context');
      invalidNode.appendChild(invalidIcon);
      invalidNode.appendChild(invalidTitle);
      invalidNode.appendChild(invalidContext);
      return invalidNode;
    },

    resetFramesPosition() {
      this.frameOffset = 0;
      this.setFramesPosition();
    },

    setFramesPosition() {
      const width = window.innerWidth + this.FRAME_BORDER_WIDTH;
      this.currentFrame.container.style.transform =
        `translateX(${this.frameOffset}px)`;
      if (Startup.lowMemory) {
        this.currentFrame.image.setAttribute('animationMode',
          'dontanim');
        this.nextFrame.image.setAttribute('animationMode',
          'dontanim');
        this.previousFrame.image.setAttribute('animationMode',
          'dontanim');
      }
      if (navigator.mozL10n.language.direction === 'ltr') {
        this.nextFrame.container.style.transform =
          `translateX(${this.frameOffset + width}px)`;
        this.previousFrame.container.style.transform =
          `translateX(${this.frameOffset - width}px)`;
      } else {
        this.nextFrame.container.style.transform =
          `translateX(${this.frameOffset - width}px)`;
        this.previousFrame.container.style.transform =
          `translateX(${this.frameOffset + width}px)`;
      }
      this.nextFrame.container.classList.remove('current');
      this.previousFrame.container.classList.remove('current');
      this.currentFrame.container.classList.add('current');
      this.nextFrame.container.setAttribute('aria-hidden',
        true);
      this.previousFrame.container.setAttribute('aria-hidden',
        true);
      this.currentFrame.container.removeAttribute('aria-hidden');
    }
  };
  exports.Frames = Frames;
}(window));
