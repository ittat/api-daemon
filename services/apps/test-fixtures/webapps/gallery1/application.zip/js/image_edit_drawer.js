'use strict';
(function (exports) { // eslint-disable-line
  const ImageDrawer = {
    selectors: null,
    selectedColor: null,
    selectedStroke: null,
    colors: null,
    drawerTool: null,

    enterDrawerView() {
      this.initImageDrawer();
      this.addEventListeners();
    },

    exitEditMode() {
      if (!this.drawerTool) {
        return;
      }
      this.removeEventListeners();
      this.selectors = null;
      this.colors = null;
    },

    initImageDrawer() {
      if (this.selectors) {
        return;
      }
      this.selectors = {
        color: 'color-selector',
        stroke: 'stroke-selector'
      };
      this.selectedColor = this.selectedColor ? this.selectedColor : 'white';
      this.selectedStroke = this.selectedStroke
        ? this.selectedStroke : 'stroke1';
      this.colors = {
        white: '#ffffff',
        black: '#000000',
        blue: '#0073e6',
        green: '#00bf60',
        yellow: '#fff01a',
        red: '#d90036'
      };
    },

    addEventListeners() {
      if (this.drawerTool) {
        return;
      }
      this.drawerTool = document.querySelector('#image-drawer-tools');
      this.drawerTool.className = '';
      this.strokeBtn = document.querySelector('#image-drawer-stroke');
      this.colorBtn = document.querySelector('#image-drawer-color');
      this.undoBtn = document.querySelector('#image-drawer-undo');
      this.redoBtn = document.querySelector('#image-drawer-redo');
      this.strokeSelector =
        document.querySelector('#image-drawer-stroke-selector');
      this.colorSelector =
        document.querySelector('#image-drawer-color-selector');
      this.strokeBtnHandle = this.showStrokeSelector.bind(this);
      this.colorBtnHandel = this.showColorSelector.bind(this);
      this.strokeSelected = this.selectStroke.bind(this);
      this.colorSelected = this.selectColor.bind(this);
      this.strokeBtn.addEventListener('click',
        this.strokeBtnHandle);
      this.colorBtn.addEventListener('click',
        this.colorBtnHandel);
      this.strokeSelector.addEventListener('click',
        this.strokeSelected);
      this.colorSelector.addEventListener('click',
        this.colorSelected);
    },

    removeEventListeners() {
      this.strokeBtn.removeEventListener('click',
        this.strokeBtnHandle);
      this.colorBtn.removeEventListener('click',
        this.colorBtnHandel);
      this.strokeSelector.removeEventListener('click',
        this.strokeSelected);
      this.colorSelector.removeEventListener('click',
        this.colorSelected);
      this.strokeBtnHandle = null;
      this.colorBtnHandel = null;
      this.strokeSelected = null;
      this.colorSelected = null;
      this.strokeBtn = null;
      this.colorBtn = null;
      this.undoBtn = null;
      this.redoBtn = null;
      this.drawerTool = null;
      this.strokeSelector = null;
      this.colorSelector = null;
    },

    showStrokeSelector() {
      this.drawerTool.classList.toggle(this.selectors.stroke);
      this.drawerTool.classList.remove(this.selectors.color);
    },

    selectStroke(e) {
      const { target } = e;
      const stroke = target.getAttribute('data-stroke');
      if (!stroke || stroke === this.selectedStroke) {
        this.drawerTool.classList.remove(this.selectors.stroke);
        return;
      }
      this.strokeSelector.querySelector(`.${this.selectedStroke}`)
        .classList.remove(this.selectedColor);
      target.classList.add(this.selectedColor);
      this.strokeBtn.classList.remove(this.selectedStroke);
      this.strokeBtn.classList.add(stroke);
      this.selectedStroke = stroke;
      this.drawerTool.classList.remove(this.selectors.stroke);
    },

    showColorSelector() {
      this.drawerTool.classList.toggle(this.selectors.color);
      this.drawerTool.classList.remove(this.selectors.stroke);
    },

    selectColor(e) {
      const { target } = e;
      const color = target.getAttribute('data-color');
      if (!color || color === this.selectedColor) {
        this.drawerTool.classList.remove(this.selectors.color);
        return;
      }
      this.colorSelector.querySelector(`.${this.selectedColor}`)
        .classList.remove('focus');
      target.classList.add('focus');
      this.strokeSelector.querySelector(`.${this.selectedStroke}`)
        .classList.remove(this.selectedColor);
      this.colorBtn.querySelector('div').classList.remove(this.selectedColor);
      this.strokeBtn.classList.remove(this.selectedColor);
      this.colorBtn.querySelector('div').classList.add(color);
      this.strokeSelector.querySelector(`.${this.selectedStroke}`)
        .classList.add(color);
      this.strokeBtn.classList.add(color);
      this.selectedColor = color;
      this.drawerTool.classList.remove(this.selectors.color);
    }
  };
  exports.ImageDrawer = ImageDrawer;
}(window));
