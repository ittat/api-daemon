'use strict';

(function (exports) {
  const Selector = {
    selectedItems: [],
    selectedBlobs: {},
    selectedInvalid: 0,
    isSelectedAll: false,
    items: null,
    actionBar: null,
    actions: {
      share: {
        title: 'Share',
        value: 'share',
        icon: 'share',
        disabled: false
      },
      addTo: {
        title: 'Add To',
        value: 'addTo',
        icon: 'browser-add',
        disabled: false
      },
      delete: {
        title: 'Delete',
        value: 'delete',
        icon: 'delete',
        disabled: false
      },
      remove: {
        title: 'Remove',
        value: 'remove',
        icon: 'remove',
        disabled: false
      }
    },
    disableActions: {
      share: {
        title: 'Share',
        value: 'share',
        icon: 'share',
        disabled: true
      },
      addTo: {
        title: 'Add To',
        value: 'addTo',
        icon: 'browser-add',
        disabled: true
      }
    },

    enterSelectView() {
      View.switchView(View.views.selectView);
      this.initContainScrollTop();
      this.initSelectAllBtn();
      this.initItems();
      this.initActions();
      this.showActionBar();
    },

    initContainScrollTop() {
      if (View.lastView === View.views.albumsView) {
        const container = document.querySelector('#albums');
        container.scrollTop = 0;
      }
    },

    initSelectAllBtn() {
      const views = [
        View.views.albumsView,
        View.views.inAlbumView,
        View.views.favoriteView
      ];
      if (views.contains(View.lastView)) {
        View.selectAllBtn.classList.remove('hidden');
      }
    },

    initItems() {
      switch (View.lastView) {
        case View.views.photosView:
          this.items = Photos.thumbnailList.getAllThumbnails();
          break;
        case View.views.albumsView:
          this.items = Album.userCreatedAlbums;
          break;
        case View.views.inAlbumView:
          this.items = InAlbum.thumbnailList.getAllThumbnails();
          break;
        case View.views.favoriteView:
          this.items = Favorite.thumbnailList.getAllThumbnails();
          break;
      }
    },

    initActions() {
      this.actionbars = {
        photosView: [
          this.actions.share,
          this.actions.addTo,
          this.actions.delete
        ],
        albumsView: [this.actions.delete],
        inAlbumView: [
          this.actions.share,
          this.actions.addTo,
          this.actions.remove,
          this.actions.delete
        ],
        favoriteView: [
          this.actions.share,
          this.actions.addTo,
          this.actions.delete
        ]
      };
      if (InAlbum.isSystem) {
        this.actionbars.inAlbumView = [
          this.actions.share,
          this.actions.addTo,
          this.actions.delete
        ];
      }
    },

    showActionBar() {
      if (!this.actionBar) {
        this.actionBar = document.querySelector('#action-bar');
        this.actionBar.addEventListener('actionbarSelect',
          this.actionbarSelectCallback.bind(this));
      }
      const actions = this.actionbars[View.lastView];
      this.actionBar.inactive = true;
      this.actionBar.setAttribute('actions',
        JSON.stringify(actions));
    },

    updateSelection(item) {
      if (this.isSelectedAll) {
        View.selectAllBtn.text = 'All';
        this.isSelectedAll = false;
      }
      item.htmlNode.classList.toggle('selected');
      const selected = item.htmlNode.classList.contains('selected');
      this.updateCheckbox(item,
        selected);
      this.updateHeaderTitle();
      this.updateActionbar();
    },

    selectAllCallback() {
      this.initItems();
      this.selectedItems = [];
      this.selectedInvalid = 0;
      if (!this.items) {
        return;
      }
      if (this.isSelectedAll) {
        for (let i = 0; i < this.items.length; i++) {
          this.items[i].htmlNode.classList.remove('selected');
          this.updateCheckbox(this.items[i],
            false);
          this.updateHeaderTitle();
          this.updateActionbar();
        }
        View.selectAllBtn.text = 'All';
        this.isSelectedAll = false;
      } else {
        for (let i = 0; i < this.items.length; i++) {
          this.items[i].htmlNode.classList.add('selected');
          this.updateCheckbox(this.items[i],
            true);
          this.updateHeaderTitle();
          this.updateActionbar();
        }
        View.selectAllBtn.text = 'None';
        this.isSelectedAll = true;
      }
    },

    selectDoneCallback() {
      View.switchView(View.lastView);
      this.resetSelection();
    },

    resetSelection() {
      this.resetCheckbox();
      this.resetContainScrollTop();
      this.selectedItems = [];
      this.selectedBlobs = {};
      this.selectedInvalid = 0;
      this.items = null;
      View.selectAllBtn.text = 'All';
      this.isSelectedAll = false;
    },

    resetContainScrollTop() {
      if (View.currentView === View.views.albumsView) {
        const container = document.querySelector('#albums');
        container.scrollTop = 0;
      }
    },

    resetCheckbox() {
      if (!this.items) {
        return;
      }
      for (let i = 0; i < this.items.length; i++) {
        this.items[i].htmlNode.classList.remove('selected');
        this.updateCheckbox(this.items[i],
          false);
      }
    },

    updateCheckbox(item, selected) {
      if (selected) {
        item.selector.setAttribute('data-icon',
          'tick');
        this.selectedItems.push(item);
        if (View.lastView !== View.views.albumsView) {
          PhotoDB.photodb.getFile(item.data.name,
            (file) => {
              this.selectedBlobs[item.data.name] = file;
            });
        }
        if (item.htmlNode.classList.contains("largeSize")) {
          this.selectedInvalid++;
        }
      } else {
        item.selector.removeAttribute('data-icon');
        const fileName = item.data.name;
        for (let i = 0; i < this.selectedItems.length; i++) {
          if (fileName === this.selectedItems[i].data.name) {
            this.selectedItems.splice(i,
              1);
            break;
          }
        }
        if (View.lastView !== View.views.albumsView) {
          delete this.selectedBlobs[item.data.name];
        }
        if (item.htmlNode.classList.contains("largeSize")) {
          if (!this.selectedInvalid) {
            return;
          }
          this.selectedInvalid--;
        }
      }
    },

    updateHeaderTitle() {
      View.header.setAttribute('title',
        `${this.selectedItems.length} Selected`);
    },

    updateActionbar() {
      if (this.selectedItems.length === 0) {
        this.actionBar.inactive = true;
      } else {
        this.actionBar.inactive = false;
      }
      if (View.views.photosView !== View.lastView) {
        return;
      }
      let actions = [];
      if (this.selectedInvalid !== 0 &&
        this.selectedItems.length === this.selectedInvalid) {
        actions = [
          this.disableActions.share,
          this.disableActions.addTo,
          this.actions.delete
        ];
      } else {
        actions = this.actionbars[View.views.photosView];
      }
      this.actionBar.setAttribute('actions',
        JSON.stringify(actions));
    },

    actionbarSelectCallback(e) {
      switch (e.detail.selected) {
        case 'share':
          this.shareSelectedFiles();
          break;
        case 'addTo':
          this.addSelectedFiles();
          break;
        case 'delete':
          this.deleteSelectedFiles();
          break;
        case 'remove':
          this.removeSelectedFiles();
          break;
      }
    },

    deleteSelectedFiles() {
      if (!this.selectedItems.length) {
        return;
      }
      let id = null;
      if (View.lastView === View.views.albumsView) {
        id = 'dialog-delete-n-albums';
      } else {
        id = 'dialog-delete-n-photos';
      }
      const message = navigator.mozL10n.get(id,
        { n: this.selectedItems.length });
      Dialog.delete.message = message;
      Dialog.showDialog(Dialog.delete,
        null,
        this.deleteFiles.bind(this));
    },

    deleteFiles() {
      Dialog.hideDialog();
      Overlay.showScanning();
      View.switchView(View.lastView);
      switch (View.currentView) {
        case View.views.photosView:
          Photos.deletePhotos(this.selectedItems,
            null,
            this.deleteFilesDone.bind(this));
          break;
        case View.views.albumsView:
          Album.deleteAlbums(this.selectedItems);
          Overlay.hideScanning();
          this.resetSelection();
          break;
        case View.views.inAlbumView:
          InAlbum.deletePhotos(this.selectedItems,
            InAlbum.deletePhoto.bind(InAlbum),
            this.deleteFilesDone.bind(this));
          break;
        case View.views.favoriteView:
          Favorite.deletePhotos(this.selectedItems,
            Favorite.deletePhoto.bind(Favorite),
            this.deleteFilesDone.bind(this));
          break;
      }
    },

    deleteFilesDone(storageSuccess) {
      this.resetSelection();
      Message.show('toast-delete-n-photos',
        { n: storageSuccess.length });
      Overlay.hideScanning();
      Album.someAlbumsRemovePhotos(storageSuccess);
      let count = 0;
      if (View.currentView === View.views.photosView) {
        count = Photos.thumbnailList.getCount();
      } else if (View.currentView === View.views.inAlbumView) {
        count = InAlbum.thumbnailList.getCount();
      } else if (View.currentView === View.views.favoriteView) {
        count = Favorite.thumbnailList.getCount();
      }
      if (!count) {
        Overlay.showEmptyPage(View.currentView);
      }
    },

    shareSelectedFiles() {
      if (!this.selectedItems.length) {
        return;
      }
      const blobs = this.selectedItems.map((item) => {
        if (!item.data.metadata.largeSize) {
          return this.selectedBlobs[item.data.name];
        }
      });
      this.selectDoneCallback();
      LaunchActivity.launchShareApps(blobs);
    },

    addSelectedFiles() {
      let options = [
        {
          data: {
            id: 'create-new-album',
            name: 'Create new album'
          }
        }
      ];
      if (Album.userCreatedAlbums.length !== 0) {
        options = options.concat(Album.userCreatedAlbums);
      }
      const custom = document.createElement('div');
      custom.setAttribute('slot',
        'custom-view');
      Array.forEach(options,
        (option) => {
          const item = document.createElement('kai-1line-listitem');
          item.setAttribute('text',
            option.data.name);
          item.classList.add('add-to-album');
          item.dataset.id = option.data.id;
          custom.appendChild(item);
          item.addEventListener('click',
            () => {
              Dialog.hideDialog();
              if (option.data.id === 'create-new-album') {
                Album.createNewAlbum();
                return;
              }
              this.addSelectedFilesToAlbum(option.data.id);
            });
        });
      Dialog.showDialog(Dialog.addToAlbum,
        custom);
      Dialog.dialog.classList.add('add-to-dialog');
    },

    addSelectedFilesToAlbum(id) {
      let addedCount = 0;
      if (this.selectedItems.length === 0) {
        return;
      }
      Array.forEach(this.selectedItems,
        (item) => {
          if (!item.data.metadata.largeSize) {
            const addSuccess = Album.addPhoto(id,
              item);
            if (addSuccess) {
              addedCount++;
            }
          }
        });
      const albumName = Album.albumsFiles[id].name;
      let addPhotoCount = null;
      let dataId = null;
      if (addedCount === 0) {
        dataId = 'toast-n-photos-already-in-album';
        addPhotoCount = this.selectedItems.length;
      } else {
        dataId = 'toast-add-n-photos';
        addPhotoCount = addedCount;
      }
      Message.show(dataId,
        { n: addPhotoCount, name: albumName });
      this.selectDoneCallback();
    },

    removeSelectedFiles() {
      if (!this.selectedItems.length) {
        return;
      }
      const message = navigator.mozL10n.get(
        'dialog-remove-n-photos',
        { n: this.selectedItems.length });
      Dialog.remove.message = message;
      Dialog.showDialog(Dialog.remove,
        null,
        this.removeFiles.bind(this));
    },

    removeFiles() {
      Dialog.hideDialog();
      Overlay.showScanning();
      View.switchView(View.lastView);
      for (let i = 0; i < this.selectedItems.length; i++) {
        InAlbum.deletePhoto(this.selectedItems[i]);
      }
      Album.anAlbumRemovePhotos(this.selectedItems,
        InAlbum.albumId);
      Message.show('toast-remove-n-photos',
        { n: this.selectedItems.length });
      Overlay.hideScanning();
      this.resetSelection();
      if (!InAlbum.thumbnailList.getCount()) {
        Overlay.showEmptyPage(View.currentView);
      }
    }
  };
  exports.Selector = Selector;
}(window));
