'use strict';
/* global ImageEditView, Dialog, ImageEditView, Preview */
(function (exports) { // eslint-disable-line
  const ImageCropRotate = {
    cropModeIDs: [
      'edit-crop-aspect-free',
      'edit-crop-aspect-original',
      'edit-crop-aspect-1x1',
      'edit-crop-aspect-2x3',
      'edit-crop-aspect-3x2',
      'edit-crop-aspect-3x4',
      'edit-crop-aspect-4x3',
      'edit-crop-aspect-9x16',
      'edit-crop-aspect-16x9'
    ],
    cropModeIDsAfterRotation: [
      'edit-crop-aspect-free',
      'edit-crop-aspect-original',
      'edit-crop-aspect-1x1',
      'edit-crop-aspect-3x2',
      'edit-crop-aspect-2x3',
      'edit-crop-aspect-4x3',
      'edit-crop-aspect-3x4',
      'edit-crop-aspect-16x9',
      'edit-crop-aspect-9x16'
    ],
    ratios: {
      'edit-crop-aspect-1x1': [1, 1],
      'edit-crop-aspect-2x3': [2, 3],
      'edit-crop-aspect-3x2': [3, 2],
      'edit-crop-aspect-3x4': [3, 4],
      'edit-crop-aspect-4x3': [4, 3],
      'edit-crop-aspect-9x16': [9, 16],
      'edit-crop-aspect-16x9': [16, 9]
    },
    toolsIDs: {
      crop: 'image-crop',
      reset: 'image-reset',
      rotate: 'image-rotate'
    },

    enterCropRotateView() {
      this.showCropOverlay();
      this.addEventListeners();
    },

    exitCropRotate() {
      ImageEditView.imageEditor.resetCrop();
      this.hideCropOverlay();
    },

    exitEditMode() {
      if (!this.tools) {
        return;
      }
      this.hideCropOverlay();
      this.removeEventListeners();
    },

    addEventListeners() {
      if (this.tools) {
        return;
      }
      this.tools = document.querySelector('#image-crop-rotate-tools');
      this.crop = this.tools.querySelector(`#${this.toolsIDs.crop}`);
      this.reset = this.tools.querySelector(`#${this.toolsIDs.reset}`);
      this.rotate = this.tools.querySelector(`#${this.toolsIDs.rotate}`);
      this.toolsClickCallback = this.toolsClickHandler.bind(this);
      this.tools.addEventListener('click',
        this.toolsClickCallback);
    },

    removeEventListeners() {
      this.tools.removeEventListener('click',
        this.toolsClickCallback);
      this.toolsClickCallback = null;
      this.tools = null;
      this.crop = null;
      this.reset = null;
      this.rotate = null;
    },

    toolsClickHandler(e) {
      const { target } = e;
      if (target === this.crop) {
        this.showRatioList();
      } else if (target === this.rotate) {
        this.rotateImage();
      } else if (target === this.reset) {
        this.resetImage();
      }
    },

    showRatioList() {
      const ratioList = this.getRatioList();
      Dialog.showDialog(Dialog.ratio,
        ratioList);
      Dialog.dialog.classList.add('select-ratio');
    },

    getRatioList() {
      const { matIdx } = ImageEditView.editSettings.rotate;
      let ratioIDS = null;
      if (matIdx === 1 || matIdx === 3) {
        ratioIDS = this.cropModeIDsAfterRotation;
      } else if (matIdx === 0 || matIdx === 2) {
        ratioIDS = this.cropModeIDs;
      }
      const ratioListContainer = document.createElement('div');
      ratioListContainer.id = 'ratio-list-container';
      ratioListContainer.setAttribute('slot',
        'custom-view');
      ratioIDS.forEach((item) => {
        const ratioNode = document.createElement('div');
        ratioNode.id = item;
        const ratioIconContainer = document.createElement('div');
        ratioIconContainer.classList.add('ratio-icon');
        const ratioIcon = document.createElement('i');
        if ('edit-crop-aspect-free' === ratioNode.id) {
          ratioIcon.setAttribute('data-icon',
            'image-free-ratio');
        } else if ('edit-crop-aspect-original' === ratioNode.id) {
          ratioIcon.setAttribute('data-icon',
            'image-crop');
        }
        ratioIconContainer.appendChild(ratioIcon);
        const ratioText = document.createElement('p');
        ratioText.classList.add('ratio-text');
        ratioText.setAttribute('data-l10n-id',
          item);
        const ratioRadioContainer = document.createElement('div');
        ratioRadioContainer.classList.add('ratio-radio');
        const ratioRadio = document.createElement('kai-radio');
        if (ratioNode.id === ImageEditView.editSettings.crop.cropModeId) {
          ratioRadio.checked = true;
        } else {
          ratioRadio.checked = false;
        }
        ratioRadioContainer.appendChild(ratioRadio);
        ratioNode.appendChild(ratioIconContainer);
        ratioNode.appendChild(ratioText);
        ratioNode.appendChild(ratioRadioContainer);
        ratioListContainer.appendChild(ratioNode);
        ratioNode.addEventListener('click',
          () => {
            if (ratioNode.id === ImageEditView.editSettings.crop.cropModeId) {
              Dialog.hideDialog();
              return;
            }
            ratioListContainer
              .querySelector(`#${ImageEditView.editSettings.crop.cropModeId}`)
              .querySelector('kai-radio').checked = false;
            ratioNode.querySelector('kai-radio').checked = true;
            ImageEditView.editSettings.crop.cropModeId = ratioNode.id;
            if (ratioNode.id === 'edit-crop-aspect-free') {
              ImageEditView.imageEditor.setCropAspectRatio();
            } else if (ratioNode.id === 'edit-crop-aspect-original') {
              if (matIdx === 1 || matIdx === 3) {
                ImageEditView.imageEditor.setCropAspectRatio(
                  Preview.previewFile.data.metadata.height,
                  Preview.previewFile.data.metadata.width);
              } else if (matIdx === 0 || matIdx === 2) {
                ImageEditView.imageEditor.setCropAspectRatio(
                  Preview.previewFile.data.metadata.width,
                  Preview.previewFile.data.metadata.height);
              }
            } else {
              const ratio = this.ratios[ratioNode.id];
              ImageEditView.imageEditor.setCropAspectRatio(ratio[0],
                ratio[1]);
            }
            Dialog.hideDialog();
          });
      });
      return ratioListContainer;
    },

    showCropOverlay() {
      ImageEditView.imageEditor.edit(() => {
        ImageEditView.imageEditor.showCropOverlay();
      });
    },

    hideCropOverlay() {
      ImageEditView.imageEditor.edit(() => {
        ImageEditView.imageEditor.hideCropOverlay();
      });
    },

    rotateImage() {
      ImageEditView.imageEditor.rotate(false);
    },

    resetImage() {
      if (this.reset.classList.contains('disabled')) {
        return;
      }
      ImageEditView.imageEditor.unRotate();
      ImageEditView.imageEditor.resetCrop();
    }
  };
  exports.ImageCropRotate = ImageCropRotate;
}(window));
