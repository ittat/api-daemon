'use strict';
(function (exports) {
  const PhotoDB = {
    PAGE_SIZE: 32,
    photodb: null,
    LazyLoadMetadataParserFile: false,
    LazyLoadPreviewFiles: false,
    LazyLoadThumbnailFiles: false,
    isInitThumbnail: false,
    creatingThumbnails: false,
    lock: null,
    galleryErrorLargeSrc: '/style/images/gallery_error.png',
    firstScreenFileNames: [],
    isFirstScreen: true,
    enumerateFiles: [],

    initPhotodb() {
      this.photodb = new MediaDB('pictures',
        this.metadataParserWrapper,
        {
          version: 2,
          autoscan: false,
          batchHoldTime: 2000,
          batchSize: 3
        });
      this.photodb.onupgrading = () => {

      };
      this.photodb.onunavailable = () => {

      };
      this.photodb.onenumerable = () => {
        this.creatingThumbnails = true;
        this.enumerateDB();
        window.performance.mark('visuallyLoaded');
      };
      this.photodb.onready = () => {
        Album.initAlbums();
      };
      this.photodb.onscanstart = () => {
        if (!this.lock) {
          this.lock = navigator.requestWakeLock('screen');
        }
      };
      this.photodb.onscanend = (e) => {
        window.performance.mark('fullyLoaded');
        this.lock.unlock();
        this.lock = null;
        if (!e.detail.containsData && Photos.thumbnailList.getCount() === 0) {
          Overlay.hideScanning();
          Overlay.showEmptyPage(View.currentView);
        }
        this.creatingThumbnails = false;
        View.selectAllBtn.classList.remove('hidden');
        if (!Startup.appLoaded) {
          Startup.appLoaded = true;
          window.dispatchEvent(new CustomEvent('moz-app-loaded'));
        }
      };
      this.photodb.onopenMediaDBFail = () => {
        window.close();
      };
      this.photodb.onnomediastorage = () => {
        View.switchView(View.views.photosView);
        Overlay.showEmptyPage(View.currentView);
      };
      this.photodb.oncardremoved = () => {
        if (Startup.picking) {
          Pick.cancel();
          return;
        }
        View.switchView(View.views.photosView);
      };
      this.photodb.oncreated = (event) => {
        event.detail.forEach(this.fileCreated.bind(this));
      };
      this.photodb.ondeleted = (event) => {
        event.detail.forEach(this.fileDeleted.bind(this));
      };
    },

    createEnumerateFiles() {
      if (this.enumerateFiles.length === 0) {
        return;
      }
      for (let i = 0; i < this.enumerateFiles.length; i++) {
        if (!this.isFirstScreen &&
          this.firstScreenFileNames.contains(this.enumerateFiles[i].name)) {
          continue;
        }
        Photos.thumbnailList.addItem(this.enumerateFiles[i],
          View.groupByDate);
      }
      if (this.isFirstScreen) {
        Overlay.hideScanning();
        Photos.lazyLoadImage.render();
        if (Startup.picking) {
          // SetView(LAYOUT_MODE.pick);
        }
      }
    },

    enumerateDB() {
      if (this.isInitThumbnail) {
        this.photodb.scan();
        return;
      }
      this.isInitThumbnail = true;
      if (this.LazyLoadThumbnailFiles) {
        Photos.initPhotos();
        return;
      }
      LazyLoader.load([
        'js/thumbnail_item.js',
        'js/thumbnail_date_group.js',
        'js/thumbnail_list.js',
        'js/lazyload_image.js',
        'js/launch_activity.js'
      ], () => {
        this.LazyLoadThumbnailFiles = true;
        Photos.initPhotos();
      });
      this.photodb.enumerate('date',
        null,
        'prev',
        (fileinfo) => {
          if (fileinfo) {
            const { metadata } = fileinfo;
            if (metadata && metadata.preview && metadata.preview.filename) {
              metadata.preview.width = Math.floor(metadata.preview.width);
              metadata.preview.height = Math.floor(metadata.preview.height);
            }
            if (Startup.picking && metadata.largeSize) {
              return;
            }
            this.enumerateFiles.push(fileinfo);
            if (this.enumerateFiles.length <= this.PAGE_SIZE) {
              this.firstScreenFileNames.push(fileinfo.name);
            }
            if (this.enumerateFiles.length === this.PAGE_SIZE) {
              this.createEnumerateFiles();
              this.isFirstScreen = false;
              window.dispatchEvent(new CustomEvent('moz-app-visually-complete'));
              window.dispatchEvent(new CustomEvent('moz-content-interactive'));
            }
          }　else {
            this.createEnumerateFiles();
            this.firstScreenFileNames = [];
            this.enumerateFiles = [];
            this.photodb.addEventListener('ready',
              () => {
                this.photodb.scan();
              });
            if (this.photodb.state === MediaDB.READY) {
              this.photodb.scan();
            }
          }
        });
    },

    fileCreated(fileinfo) {
      this.photodb.getFileInfo(fileinfo.name,
        (fileinfo) => {
          if (Overlay.current === 'emptygallery') {
            Overlay.hideEmptyPage();
          }
          if (Overlay.current === 'scanning') {
            Overlay.hideScanning();
          }
          Photos.thumbnailList.addItem(fileinfo,
            View.groupByDate);
          Photos.lazyLoadImage.render();
        });
    },

    fileDeleted(filename) {
      const fileInfo = Photos.thumbnailList.getThumbnail(filename);
      if (!fileInfo) {
        return;
      }
      Photos.thumbnailList.removeItem(fileInfo.data,
        View.groupByDate);
      const items = [];
      items.push(fileInfo);
      Album.someAlbumsRemovePhotos(items);
    },

    metadataParserWrapper(file, onsuccess, onerror, bigFile) {
      if (this.LazyLoadMetadataParserFile) {
        metadataParser(file,
          onsuccess,
          onerror,
          bigFile);
        return;
      }
      LazyLoader.load([
        'shared/js/media/downsample.js',
        'shared/js/media/jpeg_metadata_parser.js',
        'shared/js/media/image_size.js',
        'shared/js/media/crop_resize_rotate.js',
        'shared/js/blobview.js',
        'js/MetadataParser.js'
      ], () => {
        this.LazyLoadMetadataParserFile = true;
        metadataParser(file,
          onsuccess,
          onerror,
          bigFile);
      });
    },

    thumbnailClickHandler(thumbnail) {
      if (this.photodb.state !== MediaDB.READY) {
        return;
      }
      const previewPhotoViews = [
        View.views.photosView,
        View.views.inAlbumView,
        View.views.favoriteView
      ];
      if (previewPhotoViews.contains(View.currentView)) {
        if (this.LazyLoadPreviewFiles) {
          Preview.enterPreview(thumbnail);
          return;
        }
        LazyLoader.load([
          'shared/js/media/downsample.js',
          'shared/js/gesture_detector.js',
          'shared/js/format.js',
          'shared/js/media/media_frame.js',
          'js/frames.js',
          'js/preview.js',
          'js/image_edit_view.js',
          'js/image_edit_editor.js',
          'js/image_edit_webgl.js',
          'js/image_edit_crop_rotate.js',
          'js/image_edit_filter.js',
          'js/image_edit_auto_correction.js',
          'js/image_edit_ev.js',
          'js/image_edit_drawer.js',
          'style/preview.css',
          'style/image_editor.css'
        ], () => {
          this.LazyLoadPreviewFiles = true;
          Preview.enterPreview(thumbnail);
        });
      } else if (View.views.selectView === View.currentView) {
        Selector.updateSelection(thumbnail);
      } else if (View.views.pickMoreView === View.currentView) {
        PickMore.updatePick(thumbnail);
      }
    }
  };
  exports.PhotoDB = PhotoDB;
}(window));
