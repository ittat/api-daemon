'use strict';
const pickEditor = {
  canvas: null,
  previousBlob: null,
  blob: null,
  container: null,
  callback: null,
  preview: null,
  cw: 0, // Container width
  ch: 0, // Container height
  config: {
    zoomRatio: 1,
    previewX: 0,
    previewY: 0,
    previewW: 0,
    previewH: 0,
    status: '',
    cropType: 0,
    displayDest: {}
  },

  metadata: null,

  init(blob, container, cw, ch) {
    this.blob = blob;
    this.previousBlob = this.blob;
    this.container = container;
    this.cw = cw;
    this.ch = ch;
    this.createImage();
  },

  createImage() {
    const canvasNode = document.createElement('canvas');
    canvasNode.width = this.cw;
    canvasNode.height = this.ch;
    canvasNode.id = 'crop-preview-canvas'; // For stylesheet
    canvasNode.setAttribute('role',
      'img');
    this.container.appendChild(canvasNode);
    this.canvas = $("crop-preview-canvas");
    const _self = this;
    const maxsize = Startup.CONFIG_MAX_EDIT_PIXEL_SIZE ||
      Startup.CONFIG_MAX_IMAGE_PIXEL_SIZE;
    LazyLoader.load(['shared/js/media/image_size.js', 'shared/js/blobview.js', 'shared/js/media/jpeg_metadata_parser.js'],
      () => {
        getImageSize(_self.blob,
          (metadata) => {
            const imagesize = metadata.width * metadata.height;
            _self.metadata = metadata;
            if (imagesize > maxsize) {
              cropResizeRotate(_self.blob,
                null,
                Startup.CONFIG_MAX_IMAGE_PIXEL_SIZE ||
            null, null,
                null,
                (error, rotatedBlob) => {
                  Spinner.hide();
                  if (error) {
                    console.error('Error while rotating image:',
                      error);
                    rotatedBlob = file;
                  }
                  _self.drawPick(null,
                    null,
                    rotatedBlob);
                });
            } else {
              _self.drawPick();
            }
          }, () => {
            _self.drawPick();
          });
        _self.addListener();
      });
  },

  addListener() {
    window.addEventListener('keyup',
      this);
  },
  removeListener() {
    window.removeEventListener('keyup',
      this);
  },

  drawPick(data, callback, blob) {
    const self = this;
    self.config.zoomRatio = 1; // Zoom ratio
    let url = URL.createObjectURL(blob || this.blob);
    if (lowMemory) {
      const scale = window.innerWidth * window.devicePixelRatio *
        window.innerHeight * window.devicePixelRatio /
        (self.metadata.width * self.metadata.height);
      const sampleSize = Downsample.areaNoMoreThan(scale);
      url += sampleSize;
    }
    const ctx = this.canvas.getContext("2d",
      { willReadFrequently: true });
    this.preview = new Image();
    this.preview.src = url;
    this.preview.onload = function () {
      const previewWidth = self.preview.width;
      const previewHeight = self.preview.height;
      // Calculate the preview's zoom ratio
      if (previewWidth > self.cw || previewHeight > self.ch) {
        self.config.zoomRatio = self.cw / previewWidth < self.ch / previewHeight ? self.cw / previewWidth : self.ch / previewHeight;
      }
      // Calculate the preview's position and width/height
      const displayWidth = previewWidth * self.config.zoomRatio;
      const displayHeight = previewHeight * self.config.zoomRatio;
      const displayX = (self.cw - displayWidth) / 2;
      const displayY = (self.ch - displayHeight) / 2;
      self.config.previewX = self.config.previewY = 0;
      self.config.previewW = previewWidth;
      self.config.previewH = previewHeight;
      self.config.displayDest = {
        x: self.cw / 2 - displayWidth / 2,
        y: self.ch / 2 - displayHeight / 2
      };
      ctx.drawImage(self.preview,
        0,
        0,
        previewWidth,
        previewHeight,
        displayX,
        displayY,
        displayWidth,
        displayHeight);
      if (callback) {
        callback();
      }
    };
  },

  destroy() {
    this.container.removeChild(this.canvas);
    this.canvas = null;
  },

  handleEvent(dir) {
  }
};
